(ns urlshortner.core
  (:require [cheshire.core :as json]
            [urlshortner.encoder :as e])
  (:import [spark Spark Route Request Response]
           [org.slf4j Logger LoggerFactory]))

(def logger (LoggerFactory/getLogger "urlshortner.core"))

(def db (atom {}))

(defn post-url-handler
  [request response]
  (try
    (let [r (json/parse-string (.body request) true)
          url (:url r)
          short-url (e/encode url)]
      (swap! db assoc short-url url)
      (.status response 200)
      (.header response "Content-Type" "application/json")
      (json/generate-string {:shortUrl short-url}))
    (catch Exception ex
      (.error logger (str "Failed to process POST request." (.getMessage ex)))
      (throw ex))))

(defn get-url-handler
  [request response]
  (if-let [url (get @db (.params request ":short-url"))]
    (.redirect response url)
    (.status response 404)))

(defn handler
  [f]
  (reify Route
    (handle [_ ^Request request ^Response response]
      (f request response))))

(defn -main
  []
  (Spark/get "/:short-url" (handler get-url-handler))

  (Spark/post "/" (handler post-url-handler)))
