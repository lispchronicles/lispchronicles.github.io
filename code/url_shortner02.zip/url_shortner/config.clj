{:web-server-port 8000
 
 :store
 {:username "Administrator"
  :bucket "default"
  :op-timeout 100
  :uris ["http://localhost:8091/pools"]}}
