(ns urlshortner.store
  (:require [couchbase-clj.client :as cb]))

(defn open-connection
  [props]
  (cb/create-client props))

(defn close-connection
  [conn]
  (when conn
    (cb/shutdown conn)))

(defn set-data
  [conn k v]
  (cb/set conn k v))

(defn get-data
  [conn k]
  (cb/get conn k))
