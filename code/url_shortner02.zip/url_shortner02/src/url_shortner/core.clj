(ns url-shortner.core
  (:require [cheshire.core :as json]
            [url-shortner.encoder :as e]
            [url-shortner.store :as store])
  (:import [spark Spark Route Request Response]
           [org.slf4j Logger LoggerFactory]))

(def logger (LoggerFactory/getLogger "urlshortner.core"))

(def config (read-string (slurp "./config.clj")))

(def db (store/open-connection (:store config)))

(defn post-handler
  [request response]
  (try
    (let [r (json/parse-string (.body request) true)
          url (:url r)
          short-url (e/encode url)]
      (store/set-data db short-url url)
      (.status response 200)
      (.header response "Content-Type" "application/json")
      (json/generate-string {:shortUrl short-url}))
    (catch Exception ex
      (.error logger (str "Failed to process POST request." (.getMessage ex)))
      (throw ex))))

(defn get-handler
  [request response]
  (if-let [url (store/get-data db (.params request ":hash"))]
    (.redirect response url)
    (.status response 404)))

(defn make-handler
  [f]
  (reify Route
    (handle [_ ^Request request ^Response response]
      (f request response))))

(defn -main
  []
  (Spark/port (:web-server-port config))
  
  (Spark/get "/:hash" (make-handler get-handler))

  (Spark/post "/" (make-handler post-handler)))
